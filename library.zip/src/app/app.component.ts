import { Component } from '@angular/core';
import { $ } from 'protractor';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'library';
  showBooks=false;
  addedToCart=false;
  isrentout=false;
  isreturn=false;
  rentedBooks=[];
  returndata={ Username:"",
	MembershipNo:""}
  date:Date;
  renoutdetails=
  {
  Username:"",
	MembershipNo:"",
	DurationofRentalinDays:4,
	ReturnDate:""
  }
  Books = [{
    BookName: "Yellowra",
    BookID: "01",
    isbook:false
  },
  {
    BookName: "Poems",
    BookID: "02",
    isbook:false

  },
  {
    BookName: "Stories",
    BookID: "03",
    isbook:false

  }];
  

  clickMessage = '';
  addToCart(bookID,i) {   
           
    var element = <HTMLInputElement> document.getElementById(bookID);
    element.value="Added To Cart!"
    element.disabled = true;    
    this.addedToCart=true;
    this.isreturn=false;
    console.log(bookID);
    
     this.Books.forEach(e=>{
       if(e.BookID==bookID)
       {
        this.rentedBooks.push(e);
       }
     })

    console.log(this.rentedBooks);
  }

  returnbook(bookID,i)
  {

    var element1 = <HTMLInputElement> document.getElementById(bookID+"1");
     element1.disabled=true;
    this.isreturn=true;
      this.showBooks=false;
      this.addedToCart=false;


  }
  returnfinal()
  {
    if(this.returndata.Username!="" && this.returndata.MembershipNo!="")
    {
      alert("Thank You!!")
      this.returndata.Username="";
      this.returndata.MembershipNo="";
      this.isreturn=false;
    }
    else{
      alert(" Please Enter UserName and MemberShipNo!!")
    }
   
  }





  showAvailableBooks(){
    
    if(this.showBooks){
    this.showBooks=false;
    this.isreturn=false;
    }else{
      this.showBooks=true;
      this.addedToCart=false;
      this.isrentout=false;
      this.isreturn=false;
    }
  }
  rentout()
  {
    this.showBooks=false;
    this.isrentout=true;
    this.date = new Date();
    this.date.setDate( this.date.getDate() + this.renoutdetails.DurationofRentalinDays );
    this.renoutdetails.ReturnDate=this.date.toDateString();
  

  }
  confirm()
  {

    if(this.renoutdetails.Username!="" &&  this.renoutdetails.MembershipNo!="")
    {
    this.showBooks=false;
    this.isrentout=false;
    alert("Thank you and you are requested to return the book on" +''+ this.renoutdetails.ReturnDate)
    this.clear();
   
    }
    else{
      alert ("Please Fill the UserName and Membership No !! ")
    }

  }

  nameChange(event)
  {
   var regexp="/^[A-Za-z]+$";
   if(!regexp.match(event.target.value))
   {
    alert("User Name Should Contain Alphabets Only!!");
    event.target.value="";
    return false;
   }
  }


  noChange(event)
  {
   var pattern1="^[0-9]*$";
   if(!pattern1.match(event.target.value.toString()))
   {
    alert("Membership No Should Contain Numerics value Only!!");
    event.target.value="";
     return false;
     
   }
  }

  clear()
  {
    this.renoutdetails=
    {
    Username:"",
    MembershipNo:"",
    DurationofRentalinDays:4,
    ReturnDate:""
    }
    this.rentedBooks=[];
    
    
  }

 
}


