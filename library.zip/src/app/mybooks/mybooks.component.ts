import { Component, OnInit } from '@angular/core';




@Component({
  selector: 'app-mybooks',
  templateUrl: './mybooks.component.html',
  styleUrls: ['./mybooks.component.css']
})
export class MybooksComponent implements OnInit {


  constructor() { }

  ngOnInit() {


  }
  

}
