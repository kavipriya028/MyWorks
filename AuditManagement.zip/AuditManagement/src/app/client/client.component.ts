import { Component, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import {ServiceRepositoryService} from '../service-repository.service';
import { Router,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  tempval={id:"",name:"",address:"",mailid:"",mobilenumber:""};
  userdata={
    id:Date.now(),
    role:"",
  username:"",
  userpassword:""}

  isclient=false;

  @ViewChild('registerClientForm',{static: false}) clientRegisteration: NgForm;
  constructor(private service:ServiceRepositoryService,private activatedRoute:ActivatedRoute,private router:Router) { }

  ngOnInit() { 

     this.userdata.role= this.activatedRoute.snapshot.queryParamMap.get('role1');
     this.userdata.username=this.activatedRoute.snapshot.queryParamMap.get('username');
     this.userdata.userpassword=this.activatedRoute.snapshot.queryParamMap.get('password');
     if(this.userdata.role!="" && this.userdata.role!=undefined&&this.userdata.role=="client")
     {
      this.service.getdata("clientdetails?name="+this.userdata.username+"&mobilenumber"+this.userdata.userpassword).subscribe(data=>{this.tempval=data[0]}) ;
      this.isclient=true;    
     }
     else{
       this.isclient=false;
     }
     
  }

  createClient(){    
   if(this.clientRegisteration.valid){
    if(confirm("Do You Want Register Data?"))
    {
         this.service.postdata("clientdetails",this.tempval);
         this.userdata.username=this.tempval.name;
         this.userdata.userpassword=this.tempval.mobilenumber;
         this.userdata.role="client";
          this.service.postdata("userdetails",this.userdata);
         alert("Registration Done...")
         alert("Kindly Use  Name as UserName and MobileNumber as Password..");
         this.tempval={id:"",name:"",address:"",mailid:"",mobilenumber:""};
         this.router.navigateByUrl("clientdetails");
    }

   }
   else{
     alert("Please Fill All the Fields!!!")
     return;
   }

  }
  reset()
  {
   this.tempval={id:"",name:"",address:"",mailid:"",mobilenumber:""};
  }
}
