import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders, HttpParams} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ServiceRepositoryService {

  constructor(private http:HttpClient) { }

  baseurl="http://localhost:3000";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  postdata(url,data)
  {
    
    console.log("==============URL");
    console.log(url);
    console.log(data);
    this.http.post(this.baseurl+'/'+url,data).subscribe(
      (response)=>console.log(response),
      (error)=>console.log(error)
    )
    
  }

  // getdata(url)
  // {
  //   this.http.get(url).pipe(
  //     map(responseData=>{
  //       const postsArray=[];
  //       for(const key in responseData){
  //         if(responseData.hasOwnProperty(key)){
  //           postsArray.push({...responseData[key],id:key});
  //         }
  //       }
  //     })
  //   ).subscribe(posts=>{

  //     console.log(posts);
  //   })
  // }
  getdata(url)
  {
    return this.http.get(this.baseurl+'/'+url);
  }

  deletedata(url)
  {  
    console.log(this.baseurl+'/'+url);
    return this.http.delete(this.baseurl+'/'+url,this.httpOptions);
  }
  }
