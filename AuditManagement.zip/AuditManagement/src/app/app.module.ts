import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ServiceRepositoryService} from './service-repository.service'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientComponent } from './client/client.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { ClientdetailsComponent } from './clientdetails/clientdetails.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ClientComponent,
    LoginComponent,
    UserregistrationComponent,
    ClientdetailsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [ServiceRepositoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
