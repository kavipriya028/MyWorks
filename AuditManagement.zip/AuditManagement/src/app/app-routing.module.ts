import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientComponent } from './client/client.component';
import { LoginComponent } from './login/login.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { ClientdetailsComponent } from './clientdetails/clientdetails.component';

const routes: Routes = [{path: "client",
component:ClientComponent},{path: "login",
component:LoginComponent},{path: "userregistration",
component:UserregistrationComponent},{path: "clientdetails",
component:ClientdetailsComponent},
{path:"clientdetails/:role",
component:ClientdetailsComponent},
{path:"clientdetail",
component:ClientComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
