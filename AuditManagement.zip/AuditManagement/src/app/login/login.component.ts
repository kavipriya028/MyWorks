import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRepositoryService } from '../service-repository.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  logindata = {
    id: "",
    role: "",
    username: "",
    userpassword: ""
  };
  roletype = "";
  userdata: any;
  constructor(private service: ServiceRepositoryService, private Route: Router) { }

  ngOnInit() {
  
  }

  onSubmit() {
    this.service.getdata("userdetails?username=" + this.logindata.username + "&userpassword=" + this.logindata.userpassword).subscribe(b => {
      this.userdata = b;
      if (this.userdata != "" && this.userdata != undefined) {
        this.roletype = this.userdata[0].role;
        if(this.roletype.toLowerCase()=="admin" ||this.roletype.toLocaleLowerCase()=="auditor")
        {
          this.Route.navigate(["clientdetails",{role:this.roletype}]);
        }
        else if(this.roletype.toLowerCase()=="client"){
          this.Route.navigate(["clientdetail"],{queryParams:{role1:this.roletype,username:this.userdata[0].username,password:this.userdata[0].userpassword}});
        }
        
      }  
      else {
        alert("Invalid User Please Register...");
        this.logindata = {
          id: "",
          role: "",
          username: "",
          userpassword: ""
        };
        this.Route.navigateByUrl("userregistration");
      }
    })

    
    
  }

}
