import { Component, OnInit } from '@angular/core';
import {ServiceRepositoryService} from '../service-repository.service';
import { Router,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-clientdetails',
  templateUrl: './clientdetails.component.html',
  styleUrls: ['./clientdetails.component.css']
})
export class ClientdetailsComponent implements OnInit {

  constructor(private service:ServiceRepositoryService,private route:Router,private activatedRoute:ActivatedRoute) { }
  data:any=[];
  roleType="";
  isAdmin=false;
 
  ngOnInit() {
  this.service.getdata("clientdetails").subscribe(a=>{this.data=a;});
  this.roleType= this.activatedRoute.snapshot.paramMap.get('role');
  console.log("user role type is===>"+this.roleType);

  if(this.roleType=="admin")
  {
    this.isAdmin=true;
    
  }
  else if(this.roleType=="auditor")
  {
    this.isAdmin=false;
    
  }

    
  }
  deleteclient(id){    
   this.service.deletedata("clientdetails/"+id).subscribe(response=>{
   //Update list after delete is successful
    this.service.getdata("clientdetails").subscribe(a=>{this.data=a;});
   });
  }
}
