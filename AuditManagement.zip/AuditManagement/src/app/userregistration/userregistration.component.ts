import { Component, OnInit,ViewChild } from '@angular/core';
import {ServiceRepositoryService} from '../service-repository.service';
import { NgForm } from '@angular/forms';
import { Router} from '@angular/router';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {
  
  constructor(private service:ServiceRepositoryService,private route:Router) { }
 userdata={
   id:Date.now(),
   role:"",
 username:"",
 userpassword:""}
 
 
 @ViewChild('userregistrationForm',{static: false})userform: NgForm;
  ngOnInit() {    
    
  }
  createUser()
  {
    if(this.userform.valid)
    {
      if(confirm("Do you Want to Register?"))
      this.service.postdata("userdetails",this.userdata);
      this.userdata={
        id:Date.now(),
        role:"",
      username:"",
      userpassword:""}
      alert("Registration Done Sucessfully!!");

      this.route.navigateByUrl("login");
    }
    else{
      alert("Please Fill All Fields To Register...");
     
    }
    
 
    
  }

  reset()
  {
    this.userdata={
      id:Date.now(),
      role:"",
    username:"",
    userpassword:""}
  }
}
